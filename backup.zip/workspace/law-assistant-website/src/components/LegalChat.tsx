import { useState, useRef, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { 
  Send,
  MessageCircle,
  User,
  Bot
} from 'lucide-react';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

const LegalChat = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: '您好！我是法律智能助手，很高兴为您服务。请告诉我您遇到的法律问题，我会尽力为您提供专业的法律建议。',
      sender: 'bot',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<null | HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    // 添加用户消息
    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      // 模拟API调用延迟
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // 生成AI响应
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: `关于您提到的"${inputValue}"问题，根据相关法律法规，我为您提供以下分析：\n\n这是一个法律智能助手的演示响应。在实际应用中，系统会连接到专业的法律AI模型，根据您的具体问题提供准确的法律建议、相关法条引用和案例分析。\n\n请注意：此响应仅供参考，具体法律问题请咨询专业律师。`,
        sender: 'bot',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botResponse]);
    } catch (error) {
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: '抱歉，我在处理您的问题时遇到了一些技术问题。请稍后再试，或联系技术支持。',
        sender: 'bot',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const quickQuestions = [
    "合同纠纷如何处理？",
    "劳动法相关问题",
    "知识产权保护",
    "婚姻家庭法律问题",
    "交通事故赔偿",
    "刑事辩护咨询"
  ];

  const handleQuickQuestion = (question: string) => {
    setInputValue(question);
  };

  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto">
      {/* 聊天头部 */}
      <Card className="mb-4">
        <CardHeader className="bg-blue-50 rounded-t-lg">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-100 p-2 rounded-full">
              <MessageCircle className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <CardTitle className="text-xl font-semibold">法律智能助手</CardTitle>
              <p className="text-sm text-gray-500">AI法律咨询专家 - 实时为您解答法律问题</p>
            </div>
            <div className="ml-auto flex space-x-2">
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                在线
              </Badge>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* 消息历史 */}
      <div className="flex-1 overflow-y-auto mb-4 max-h-[500px]">
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl p-4 ${
                  message.sender === 'user'
                    ? 'bg-blue-500 text-white rounded-br-none'
                    : 'bg-gray-100 text-gray-800 rounded-bl-none'
                }`}
              >
                <div className="flex items-start space-x-2">
                  {message.sender === 'bot' && (
                    <div className="bg-blue-200 p-1 rounded-full mt-0.5">
                      <Bot className="h-4 w-4 text-blue-600" />
                    </div>
                  )}
                  {message.sender === 'user' && (
                    <div className="bg-blue-600 p-1 rounded-full mt-0.5">
                      <User className="h-4 w-4 text-white" />
                    </div>
                  )}
                  <div className="flex-1">
                    <div className="whitespace-pre-wrap">{message.content}</div>
                    <div
                      className={`text-xs mt-1 ${
                        message.sender === 'user' ? 'text-blue-100' : 'text-gray-500'
                      }`}
                    >
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="max-w-[80%] rounded-2xl p-4 bg-gray-100 text-gray-800 rounded-bl-none">
                <div className="flex items-center space-x-2">
                  <div className="bg-blue-200 p-1 rounded-full">
                    <Bot className="h-4 w-4 text-blue-600" />
                  </div>
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-100"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-200"></div>
                  </div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* 快速问题 */}
      <div className="mb-4">
        <h3 className="text-sm font-medium text-gray-700 mb-2">快速提问</h3>
        <div className="grid grid-cols-2 gap-2">
          {quickQuestions.map((question, index) => (
            <Button
              key={index}
              variant="outline"
              size="sm"
              className="text-left text-xs"
              onClick={() => handleQuickQuestion(question)}
            >
              {question}
            </Button>
          ))}
        </div>
      </div>

      {/* 输入区域 */}
      <div className="flex space-x-2">
        <Input
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="输入您的法律问题..."
          className="flex-1"
          disabled={isLoading}
        />
        <Button
          onClick={handleSendMessage}
          disabled={isLoading || !inputValue.trim()}
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Send className="h-4 w-4" />
        </Button>
      </div>

      {/* 信息提示 */}
      <div className="mt-4 text-xs text-gray-500 text-center">
        <p>此为AI法律咨询助手，提供的建议仅供参考，具体法律问题请咨询专业律师</p>
      </div>
    </div>
  );
};

export default LegalChat;