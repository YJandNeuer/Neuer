import LegalChat from './components/LegalChat';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 2L2 7l10 5 10-5-10-5z" />
              <path d="M2 17l10 5 10-5" />
              <path d="M2 12l10 5 10-5" />
            </svg>
            <h1 className="text-2xl font-bold text-gray-800">法律智能助手</h1>
          </div>
          <nav>
            <ul className="flex space-x-6">
              <li><a href="#" className="text-gray-600 hover:text-blue-600 font-medium">首页</a></li>
              <li><a href="#" className="text-blue-600 font-medium">法律咨询</a></li>
              <li><a href="#" className="text-gray-600 hover:text-blue-600 font-medium">法律法规</a></li>
              <li><a href="#" className="text-gray-600 hover:text-blue-600 font-medium">关于我们</a></li>
            </ul>
          </nav>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <section className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">专业法律咨询，智能解答</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            24小时在线法律智能助手，为您提供专业、准确的法律咨询服务
          </p>
        </section>

        {/* Chat Interface */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <LegalChat />
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-6 mt-8">
        <div className="container mx-auto px-4 text-center">
          <p>© 2025 法律智能助手. 保留所有权利.</p>
          <p className="text-gray-400 text-sm mt-2">此为AI法律咨询助手，提供的建议仅供参考，具体法律问题请咨询专业律师</p>
        </div>
      </footer>
    </div>
  );
}

export default App;