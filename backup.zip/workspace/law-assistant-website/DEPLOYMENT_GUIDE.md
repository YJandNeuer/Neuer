# 部署到 Vercel 指南

## 法律智能助手网站部署说明

您的法律智能助手网站已经创建完成，以下是部署到 Vercel 的详细步骤：

### 方法一：使用 Git 仓库部署（推荐）

1. 创建 GitHub/GitLab 仓库
   ```bash
   # 在项目根目录执行
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin YOUR_REPOSITORY_URL
   git push -u origin main
   ```

2. 访问 [Vercel](https://vercel.com/)
   - 使用 GitHub/GitLab 账户登录
   - 点击 "New Project"
   - 选择您刚刚创建的仓库
   - Vercel 会自动检测到这是一个 Vite 项目
   - 点击 "Deploy" 开始部署

### 方法二：直接上传构建文件

1. 下载构建文件
   - 项目已构建完成，构建文件位于 `dist` 目录
   - 或使用已创建的压缩包 `law-assistant-website-build.zip`

2. 上传到 Vercel
   - 访问 [Vercel Dashboard](https://vercel.com/dashboard)
   - 点击 "New Project"
   - 选择 "Upload a ZIP file"
   - 上传 `law-assistant-website-build.zip` 文件
   - 点击 "Deploy" 开始部署

### 项目技术栈

- **框架**: React + TypeScript
- **构建工具**: Vite
- **样式**: Tailwind CSS
- **UI 组件**: shadcn/ui
- **图标**: Lucide React

### 项目结构

```
law-assistant-website/
├── src/
│   ├── components/       # 自定义组件
│   │   └── LegalChat.tsx # 专业法律对话组件
│   ├── components/ui/    # UI 组件
│   ├── App.tsx           # 主应用组件
│   └── main.tsx          # 应用入口
├── public/               # 静态资源
├── package.json          # 项目依赖
├── vite.config.ts        # Vite 配置
├── tailwind.config.js    # Tailwind 配置
└── dist/                 # 构建输出目录
```

### 本地开发

```bash
# 安装依赖
npm install

# 启动开发服务器
npm run dev

# 构建生产版本
npm run build
```

### 专业对话页面特性

新创建的法律智能助手网站具有以下特性：

1. **专业对话界面**：现代化的聊天界面，区分用户和AI消息
2. **实时交互**：支持实时消息发送和接收
3. **快速提问**：提供常见法律问题快速选择
4. **响应式设计**：适配各种设备屏幕
5. **加载状态**：显示AI响应加载状态
6. **消息历史**：保持完整的对话历史记录

### 自定义配置

如需修改网站内容或功能，可以编辑 `src/App.tsx` 文件或 `src/components/LegalChat.tsx` 文件。网站使用了现代化的 UI 组件，支持响应式设计，适配各种设备。

### 连接后端服务

要实现真正的法律AI对话功能，您需要：

1. 集成法律AI API（如OpenAI GPT或其他法律专业模型）
2. 在 `LegalChat.tsx` 组件中替换模拟的API调用
3. 添加用户认证和数据存储功能
4. 部署后端服务（可使用Vercel Functions、AWS Lambda等）

### 注意事项

1. 本项目为纯静态网站，不包含后端服务
2. 法律咨询功能目前为演示状态，实际部署时需要连接后端 API
3. 如需添加后端功能，建议使用 Vercel Functions 或其他云函数服务
4. 网站已优化 SEO，包含适当的 meta 标签
5. 遵守相关法律法规，在法律咨询页面添加免责声明

### 支持

如在部署过程中遇到问题，请参考 Vercel 官方文档或联系技术支持。
